# Lean 4 w ekonomii matematycznej: pierwsze seminarium

Materiał dla studenta i promotora rozpoczynających pracę z Leanem. Pierwsza część dotyczy czystej matematyki i narzędzi dowodowych; druga przenosi te narzędzia na proste modele mikroekonomiczne. Zakładamy znajomość klasycznych dowodów matematycznych, bez znajomości programowania funkcyjnego.

**Rezultat:** uczestnik odczytuje stan dowodu, rozróżnia definicje od twierdzeń i założeń, wybiera podstawową taktykę według postaci celu oraz potrafi przeanalizować kilka zakończonych formalizacji ekonomicznych.


## 1. Zawartość i uruchomienie

| Plik | Zastosowanie |
| --- | --- |
| `Seminarium01.lean` | Główny skrypt: podstawy, przykłady matematyczne, zastosowania ekonomiczne; komentarze wyjaśniają kolejne kroki |
| `Cwiczenia01.lean` | 12 zadań do samodzielnego rozwiązania |
| `Rozwiazania01.lean` | Kompletne rozwiązania zadań |
| `Przewodnik_Seminarium01.md` | Plan zajęć, objaśnienia, mapa taktyk i ścieżka dalszej nauki |
| `lean-toolchain` | Przypięta wersja Leana |
| `lakefile.lean` | Przypięta wersja Mathlib i definicja projektu |

Po rozpakowaniu pakietu otwórzcie cały folder w VS Code z oficjalnym rozszerzeniem Lean 4. W terminalu tego folderu wykonajcie:

```sh
lake update
lake exe cache get
lake env lean Seminarium01.lean
lake env lean Rozwiazania01.lean
```

`lake update` przygotowuje zależności opisane w konfiguracji; wersja Mathlib jest przypięta do konkretnego commitu. `lake exe cache get` pobiera gotowe artefakty biblioteki. `lake env lean ...` sprawdza plik w środowisku projektu. Pierwsze uruchomienie może wymagać pobrania Leana i Mathlib. Samo zapisanie `import Mathlib` nie instaluje biblioteki.

Powstały po inicjalizacji `lake-manifest.json` zachowajcie w swoim repozytorium razem z konfiguracją. Nie zmieniajcie wersji w trakcie przygotowania seminarium. Najpierw sprawdźcie, że działają pliki dołączone do pakietu.

Jeśli VS Code zgłasza nieznany moduł `Mathlib`, sprawdźcie, czy otwarty jest folder projektu zawierający `lakefile.lean`, a nie sam luźny plik lub jego podfolder. W razie problemów z instalacją możliwa jest demonstracja w oficjalnym edytorze internetowym: https://live.lean-lang.org/. Jego wersja Mathlib może różnić się od przypiętej wersji pakietu.

### Symbole z klawiatury

W edytorze Leana wpisz sekwencję i zatwierdź spacją lub Tab:

| Symbol | Sekwencja |
| --- | --- |
| `ℝ`, `ℕ` | `\R`, `\N` |
| `≤`, `≠` | `\le`, `\ne` |
| `∀`, `∃` | `\forall`, `\exists` |
| `→`, `↔` | `\to`, `\iff` |
| `∧`, `∨`, `¬` | `\and`, `\or`, `\not` |
| `⟨`, `⟩` | `\langle`, `\rangle` |
| `←`, `·` | `\l`, `\.` |

## 2. Plan spotkania

| Czas | Temat i praca | Wynik kontrolny |
| --- | --- | --- |
| 0-10 min | Cel formalizacji, Curry-Howard, twierdzenie a dowód | Wyjaśniamy, dlaczego `#check` nie dowodzi zdania |
| 10-25 min | Część A skryptu: składnia i Infoview | Odczytujemy obiekty, założenia oraz tezę za `⊢` |
| 25-45 min | Część B: implikacje, kwantyfikatory, koniunkcje | Samodzielnie rozwiązujemy ćwiczenia 1 i 3 |
| 45-60 min | Część C: podstawianie, upraszczanie, tożsamości | Przewidujemy cel po `rw [h]` |
| 60-70 min | Część D: nierówności i granice automatyzacji | Rozpoznajemy różnicę między `linarith` i `nlinarith` |
| 70-80 min | Przerwa | |
| 80-95 min | Części E-F: założenia modelu, użyteczność i preferencje | Odczytujemy kierunek relacji i wskazujemy rolę `ha` |
| 95-120 min | Część G: zbiór budżetowy i jego wypukłość | Tłumaczymy każdy krok dowodu na język matematyczny |
| 120-135 min | Część H: maksimum funkcji kwadratowej | Oddzielamy wskazanie kandydata, dopuszczalność i optymalność |
| 135-150 min | Ćwiczenia 7 i 10; wybór własnego lematu | Formułujemy pierwszy mały cel badawczy i jego założenia |

Część I o indukcji jest dodatkiem. W wariancie 90-minutowym po podstawach wybierzcie monotoniczność użyteczności i optimum kwadratowe; wypukłość zbioru przełóżcie na drugie spotkanie.

**Podział pracy:** jedna osoba obsługuje edytor, druga przed każdym krokiem mówi, jaki powinien być następny cel. Po około 20 minutach zamieniacie się rolami. Promotor ocenia sens matematyczny definicji i kompletność założeń; student i promotor wspólnie uczą się składni oraz nawigacji po bibliotece. Przed uruchomieniem automatyzacji zapisujcie jednym zdaniem matematyczny pomysł dowodu.

## 3. Jak Lean traktuje matematykę

### 3.1. Curry-Howard w wersji roboczej

W zwykłej matematyce odróżniamy obiekt, zdanie o obiekcie oraz dowód tego zdania. W Leanie wszystkie te elementy mają formalne reprezentacje.

| Zapis | Interpretacja |
| --- | --- |
| `x : ℝ` | x jest liczbą rzeczywistą |
| `P : Prop` | P jest zdaniem logicznym |
| `h : P` | h jest dowodem P |
| `f : ℝ → ℝ` | f jest funkcją z liczb rzeczywistych w liczby rzeczywiste |
| `hPQ : P → Q` | hPQ przekształca dowód P w dowód Q; jest dowodem implikacji |

To praktyczny sens korespondencji Curry'ego-Howarda: **zdania występują jako typy, a dowody jako termy tych typów**. Aby udowodnić P, konstruujemy term typu P. Na początku nie trzeba uczyć się całej teorii typów zależnych.

Przykład `exact hPQ hP` odzwierciedla modus ponens: mając dowód implikacji P → Q i dowód P, dostajemy dowód Q. Zastosowanie dowodu ma składnię podobną do zastosowania funkcji.

Taktyki są instrukcjami budowania dowodu. Typowe taktyki używane w skrypcie, takie jak `ring` i `linarith`, wytwarzają termy dowodowe sprawdzane przez jądro Leana. System nie akceptuje wyniku dlatego, że taktyka zgłosiła sukces; musi jeszcze zaakceptować zbudowany dowód.

### 3.2. Co robią deklaracje

| Konstrukcja | Rola |
| --- | --- |
| `def` | Wprowadza definicję, np. funkcję wydatków lub relację preferencji |
| `theorem` | Wprowadza nazwane twierdzenie wraz z dowodem |
| `example` | Sprawdza przykład bez nadawania mu użytecznej globalnej nazwy |
| `#check` | Pokazuje typ wyrażenia; nie rozstrzyga prawdziwości zdania |
| `#print` | Pokazuje treść deklaracji |
| `#print axioms nazwa` | Pokazuje zależności aksjomatyczne wskazanego wyniku |
| `sorry` | Wstawia brakujący fragment przy użyciu `sorryAx`; oznacza nieukończoną formalizację |

`#check ((2 : ℝ) + 2 = 5)` daje zdanie typu `Prop`, ponieważ jest ono sensownie zapisane. Nie daje dowodu tej fałszywej równości. Podobnie samo istnienie deklaracji z `sorry` nie oznacza, że dowód jest ukończony.

### 3.3. Anatomia twierdzenia i stanu dowodu

Przykład ze skryptu ma postać:

```lean
example (x y z : ℝ) (hxy : x ≤ y) (hyz : y ≤ z) : x ≤ z := by
  apply le_trans hxy
  exact hyz
```

Przed pierwszą taktyką stan jest następujący:

```text
x y z : ℝ
hxy : x ≤ y
hyz : y ≤ z
⊢ x ≤ z
```

Po `apply le_trans hxy` teza zmienia się na `y ≤ z`. System dopasował schemat przechodniości do celu, wykorzystał pierwszą przesłankę i poprosił o brakującą. Następnie `exact hyz` dostarcza ten dowód. W edytorze ustawiajcie kursor po każdej taktyce i porównujcie przewidywany stan z Infoview.

Ważne elementy składni:

- `:` oddziela obiekt od jego typu, a w deklaracji twierdzenia także wprowadza jego treść.
- `:=` wprowadza definicję lub dowód.
- `by` rozpoczyna dowód w trybie taktyk.
- `fun x => ...` zapisuje funkcję przez podanie argumentu i wartości.
- `·` rozpoczyna osobny poddowód; wcięcia wyznaczają strukturę bloków.
- `_` zwykle oznacza fragment do wywnioskowania; `?_` jest nazwanym przez system otwartym miejscem na dowód w odpowiednim kontekście.
- `(x : X)` oznacza argument jawny, `{x : X}` argument zwykle wywnioskowywany, a `[Struktura X]` dostępną instancję struktury, np. porządku lub grupy.

Nie trzeba pisać osobnego dowodu termowego i taktycznego. To dwa sposoby konstruowania tego samego rodzaju obiektu.

## 4. Mapa taktyk według problemu

Nie próbujcie zapamiętać całej tabeli. Przed wyborem narzędzia odczytajcie główny operator celu: implikację, koniunkcję, kwantyfikator, równość albo nierówność.

| Narzędzie | Typowy problem | Co robi | Ograniczenie lub uwaga |
| --- | --- | --- | --- |
| `exact h` | Dowód tezy jest już dostępny | Dostarcza kompletny dowód bieżącego celu | Treść musi odpowiadać celowi, z uwzględnieniem równości definicyjnej |
| `intro x` / `intro h` | Cel `∀ x, ...` lub `P → Q` | Wprowadza dowolny obiekt lub zakładaną przesłankę | Nazwy są wybierane przez autora dowodu |
| `apply lemma` | Chcemy wykorzystać twierdzenie o odpowiednim wniosku | Zastępuje cel brakującymi przesłankami twierdzenia | Nie dowodzi tych przesłanek automatycznie |
| `constructor` | Cel `P ∧ Q` albo `P ↔ Q` | Tworzy dwa cele: składniki lub kierunki | Dla równoważności powstają implikacje |
| `obtain ⟨...⟩ := h` | Hipoteza jest koniunkcją lub twierdzeniem egzystencjalnym | Wyciąga składniki dowodu, świadka i jego własności | Odkrywa obiekt z hipotezy, nie wybiera świadka tezy |
| `rcases h with ...` | Rozpakowywanie danych logicznych | Dzieli złożoną hipotezę, także na przypadki | Na początku wystarcza prosty wzorzec `⟨h1, h2⟩` |
| `use x` | Cel `∃ x, P x` | Wskazuje świadka | Pozostaje udowodnić jego własności |
| `left` / `right` | Cel `P ∨ Q` | Wybiera składnik do udowodnienia | Gdy alternatywa jest hipotezą, potrzebny jest podział na przypadki |
| `rfl` | Równość definicyjna | Zamyka cel po dozwolonej redukcji definicji i obliczeń | Nie jest ogólnym narzędziem algebry, np. przemienność z parametrami wymaga twierdzenia |
| `rw [h]` | Podstawienie według równości | Przepisuje cel; `at h1` przepisuje wskazaną hipotezę | `← h` odwraca kierunek; znaczenie ma dopasowanie wyrażenia |
| `simp [definicja, h]` | Upraszczanie wyrażeń i logiki | Stosuje reguły biblioteczne i wskazane informacje | Nie jest uniwersalnym dowodem; jawnie podawaj potrzebne hipotezy |
| `change ...` | Chcemy jawnie odsłonić definicję | Zastępuje cel definicyjnie równoważnym zapisem | Nie pozwala dowolnie zmieniać treści twierdzenia |
| `have h : P := ...` | Potrzebny lemat pomocniczy | Dodaje do kontekstu uprzednio uzasadniony fakt | Fakt trzeba rzeczywiście udowodnić |
| `calc` | Łańcuch równości lub nierówności | Organizuje kolejne kroki i ich uzasadnienia | Jest konstrukcją zapisu dowodu, a nie solverem |
| `ring` | Tożsamości wielomianowe | Normalizuje działania w odpowiednich strukturach algebraicznych | Nie rozwiązuje dowolnych równań i nie zastępuje podstawienia według założenia |
| `norm_num` | Konkretne rachunki i porównania liczbowe | Oblicza i uzasadnia wynik | Zmienne i struktura problemu mogą wymagać innych narzędzi |
| `linarith` | Liniowe równości i nierówności, szczególnie nad `ℚ`, `ℝ` | Łączy informacje arytmetyczne z kontekstu | Nie jest solverem ogólnej nieliniowej optymalizacji |
| `nlinarith` | Niektóre nierówności wielomianowe | Rozszerza rozumowanie liniowe o wstępne kroki nieliniowe | Nie jest procedurą kompletną; czasem trzeba podać np. `sq_nonneg (...)` |
| `positivity` | Dodatniość, nieujemność i wybrane cele o niezerowości | Analizuje znaki składników wyrażenia | Potrzebuje odpowiednich informacji o składnikach |
| `omega` | Liniowa arytmetyka `ℕ` i `ℤ` | Uwzględnia dyskretność, obsługuje też szereg celów z dzieleniem i resztą | Nie służy do analizy nad `ℝ` ani ogólnych iloczynów zmiennych |
| `field_simp [hx]` | Równości z ułamkami | Usuwa mianowniki, korzystając z warunków takich jak `x ≠ 0` | Przy nierównościach trzeba kontrolować znak; nie stosować mechanicznie |
| `induction n with ...` | Twierdzenie o wszystkich liczbach naturalnych lub rekurencji | Tworzy bazę i krok z hipotezą indukcyjną | Nie uruchamiaj ponownie indukcji bez planu; wykorzystaj otrzymaną hipotezę |

### Dlaczego `linarith` nie wystarcza do wszystkiego?

Wniosek `x ≤ 3` z `2*x + y ≤ 7` i `1 ≤ y` jest liniowy. Kombinacja odpowiednich nierówności zamyka dowód. Natomiast przejście z `x ≤ y` do `a*x ≤ a*y` wymaga informacji o znaku `a`, a zawiera iloczyny zmiennych. W skrypcie ten krok wykonuje jawnie twierdzenie `mul_le_mul_of_nonneg_left`.

Dla `2*x*y ≤ x^2 + y^2` pomysłem jest `(x-y)^2 ≥ 0`. Polecenie `have` dodaje tę przesłankę, a `nlinarith` wykonuje pozostały rachunek. Zachowujemy w ten sposób matematyczne uzasadnienie w czytelnej postaci.

### Aksjomatyka nie jest osobną taktyką

Taktyka jest metodą budowy dowodu; aksjomat jest przyjętym założeniem. Można zdefiniować abstrakcyjną relację R i założyć jej przechodniość, a następnie wyprowadzać konsekwencje za pomocą `intro`, `apply` i `exact`.

W części E przechodniość występuje jako lokalna hipoteza `hTrans`. W drugim przykładzie `[AddCommMonoid G]` udostępnia własności struktury algebraicznej, z których korzysta `add_comm`. Nie konstruujemy liczb rzeczywistych ani ich działań.

Globalne `axiom nazwa : P` dodaje P bez dowodu. Nie używajcie tego polecenia do omijania trudnego kroku. Jeżeli model ma założenia o preferencjach, zapisujcie je jako parametry twierdzeń lub pola odpowiedniej struktury. Wówczas wynik ma jasną postać: z tych założeń wynika ta teza. Sam Lean nie dowodzi niesprzeczności dowolnie dodanych aksjomatów ani trafności empirycznej modelu.

## 5. Omówienie zastosowań ekonomicznych

### 5.1. Monotoniczność użyteczności afinicznej

Rozważamy u(x) = ax + b i a ≥ 0. Dla x ≤ y mnożymy przez a, zachowując kierunek nierówności, po czym dodajemy b. Część F formalizuje dokładnie te dwa kroki.

`Monotone f` w Mathlib oznacza funkcję **niemalejącą**: x ≤ y implikuje f(x) ≤ f(y). Ścisłą rosnącość opisuje `StrictMono`. Przy a = 0 funkcja jest stała, więc z a ≥ 0 nie wynika ścisła rosnącość. Ćwiczenie 8 wymaga silniejszego założenia a > 0.

Warto na głos zapytać: gdzie użyliśmy znaku a? Odpowiedź powinna wskazać zastosowanie twierdzenia o mnożeniu nierówności. Usunięcie założenia a ≥ 0 zmienia prawdziwość twierdzenia, a nie tylko wygodę pracy taktyki.

### 5.2. Preferencje reprezentowane przez użyteczność

Przyjmujemy konwencję x ≽ y wtedy i tylko wtedy, gdy u(y) ≤ u(x). Funkcja u ma dowolną dziedzinę X i wartości w ℝ. Nie zakładamy wypukłości, topologii ani skończoności X.

Dowodzimy:

1. Zwrotności: x ≽ x.
2. Przechodniości: x ≽ y oraz y ≽ z implikują x ≽ z.
3. Zupełności: dla każdych x, y zachodzi x ≽ y lub y ≽ x.

Wszystkie trzy własności dziedziczymy z porządku liczb rzeczywistych. Ten wynik dotyczy relacji już zdefiniowanej przez u. Twierdzenie, że pewna abstrakcyjnie zadana relacja ma reprezentację użytecznościową, byłoby osobnym zadaniem z innymi założeniami.

Nie dowiedliśmy też antysymetrii preferencji na X. Różne alternatywy mogą mieć tę samą użyteczność. Nie należy utożsamiać obojętności z równością alternatyw.

### 5.3. Zbiór budżetowy dwóch dóbr

Koszyk to para x = (x₁, x₂). Przy zadanych cenach wydatki wynoszą p₁x₁ + p₂x₂. Definiujemy:

```text
B(p,w) = {x ∈ ℝ² : x₁ ≥ 0, x₂ ≥ 0, p₁x₁ + p₂x₂ ≤ w}.
```

Pierwszy wynik to B(p,w₁) ⊆ B(p,w₂), gdy w₁ ≤ w₂. `intro x hx` wybiera koszyk z pierwszego zbioru; `obtain` rozpakowuje warunki; przechodniość daje nowy limit wydatków.

Drugi wynik to `Convex ℝ (budgetSet p₁ p₂ w)`, czyli wypukłość z użyciem standardowej definicji Mathlib. Nie wprowadzamy odrębnej, uproszczonej definicji wypukłości.

Dowód bierze x,y ∈ B oraz a,b ≥ 0 z a+b=1. Trzeba sprawdzić, że ax+by ma nieujemne obie składowe oraz spełnia budżet. `positivity` rozwiązuje dwa pierwsze cele. Dla wydatków zapisujemy łańcuch:

```text
spending(ax+by)
  = a*spending(x) + b*spending(y)
  ≤ a*w + b*w
  = (a+b)*w
  = w.
```

Przejście od pierwszego do drugiego wiersza opiera się na liniowości wydatków; `ring` sprawdza odpowiednią tożsamość. Nierówność wymaga nieujemności wag, a ostatni krok warunku a+b=1. Zapis `a • x` oznacza mnożenie wektora przez skalar; w składowych odpowiada zwykłemu mnożeniu liczb.

**Założenia:** wypukłość zachodzi tutaj dla dowolnych rzeczywistych cen i dochodu. Nie oznacza to, że zbiór jest niepusty lub ograniczony. Dla niepustości wystarczy w ≥ 0, bo dopuszczalny jest koszyk zerowy; to osobne ćwiczenie 11. Dodatnie ceny stają się istotne np. przy rozważaniu ograniczoności zbioru.

### 5.4. Globalne optimum funkcji kwadratowej

Dla u_A(x) = Ax - x² kandydatem jest x* = A/2. Matematyczny certyfikat optymalności jest prosty:

```text
u_A(A/2) - u_A(x) = (x - A/2)² ≥ 0.
```

W skrypcie `dsimp` odsłania definicję funkcji, `have` wprowadza nieujemność kwadratu, a `nlinarith` kończy rachunek. Pierwszy wynik obowiązuje na całym ℝ i nie wymaga A ≥ 0.

Drugi wynik dotyczy dziedziny x ≥ 0. Założenie A ≥ 0 pozwala sprawdzić, że kandydat A/2 jest dopuszczalny. `use` wskazuje kandydata, `constructor` oddziela dopuszczalność od optymalności, a udowodnione wcześniej oszacowanie globalne uzasadnia maksimum także na tej dziedzinie.

Nie używamy warunku pierwszego rzędu. Jest to pełne oszacowanie globalne, a nie tylko warunek konieczny. Gdy A < 0, A/2 nie jest dopuszczalne dla x ≥ 0; wówczas maksimum na tej dziedzinie osiąga x = 0. Tego wariantu skrypt nie formalizuje i można uczynić z niego następny projekt.

## 6. Ćwiczenia i kryterium opanowania

W czasie seminarium wystarczą zadania 1, 3, 7 i 10. Pozostałe przeróbcie po spotkaniu. Zadania 8 i 11 są przejściem do samodzielnego używania założeń modelu.

| Zadania | Umiejętność | Jak sprawdzić zrozumienie |
| --- | --- | --- |
| 1-3 | Czytanie kontekstu i logiki | Przed taktyką potrafisz nazwać kolejny cel |
| 4-5 | Świadek i podstawienie | Wyjaśniasz, dlaczego wybrany świadek działa i gdzie wykorzystano h |
| 6-7 | Dobór automatyzacji | Wskazujesz liniową kombinację lub nieujemny kwadrat |
| 8-9 | Znaczenie założeń | Podajesz kontrprzykład po usunięciu założenia o znaku |
| 10-12 | Zastosowanie ekonomiczne | Rozdzielasz prawdziwość twierdzenia od interpretacji ekonomicznej |

Nie uznawajcie zadania za opanowane wyłącznie dlatego, że po wklejeniu rozwiązania zniknęły błędy. Odtwórzcie je w pustym bloku dowodu i wyjaśnijcie rolę każdego założenia.

## 7. Jak efektywnie dojść do własnych wyników

### Pierwsze cztery tygodnie: proponowana organizacja

| Okres | Główny cel | Konkretny rezultat |
| --- | --- | --- |
| Tydzień 1 | Infoview, `intro`, `exact`, `apply`, `rw`, `simp`; logika i równości | Odtworzone podstawy skryptu i rozwiązane zadania 1-7 |
| Tydzień 2 | Definicje modelu, relacje, porządki, funkcje | Własna relacja preferencji oraz 3-5 małych lematów o jej własnościach |
| Tydzień 3 | Zbiory, inkluzje, wypukłość i ograniczenia | Uogólnienie jednego wyniku budżetowego albo wariantu optimum |
| Tydzień 4 | Fragment rzeczywistego projektu | Sformalizowany mały lemat z Waszego modelu wraz z jawną listą założeń |

To propozycja organizacji pracy, nie gwarancja tempa. Złożoność własnego wyniku zależy przede wszystkim od potrzebnych pojęć i dostępnego interfejsu bibliotecznego. Krótki dowód na papierze może wymagać wielu kroków formalnych.

**Najbardziej produktywny cykl pracy:**

1. Zapisz twierdzenie na papierze z dziedzinami i wszystkimi założeniami.
2. Oddziel obiekty modelu od własności: zbiór wyboru, relacja, funkcja celu, dopuszczalność.
3. Poszukaj odpowiadających im definicji Mathlib. Używaj `Monotone`, `Convex`, `Set` i innych istniejących interfejsów, gdy odpowiadają matematycznemu zamiarowi.
4. Rozpisz dowód na lematy o jednym zadaniu. Najpierw formalizuj najprostszy niebanalny lemat.
5. Używaj `#check` do sprawdzenia typów twierdzeń i narzędzi `exact?`, `apply?`, `rw?`, `simp?` do poszukiwania kroków. Odczytaj znalezione rozwiązanie przed jego przyjęciem.
6. Po zamknięciu dowodu sprawdź, czy twierdzenie ma właściwą treść: dziedziny, znaki, kierunek preferencji, brak niezamierzonych trywializacji.
7. Usuń wszystkie `sorry` z ukończonych wyników, przejrzyj zależności przez `#print axioms` i zapisz wersję projektu w Git.

Wyszukiwanie twierdzeń i rozumienie ich parametrów jest osobną umiejętnością. Dla osoby z mocnym zapleczem matematycznym często wymaga więcej praktyki niż same matematyczne argumenty. Nie trzeba przerabiać całej konstrukcji ℝ ani odtwarzać standardowej algebry, aby zacząć własny model.

### Proponowane kolejne mini-projekty

- Relacja obojętności indukowana przez u jest relacją równoważności.
- Ściśle rosnąca transformacja użyteczności zachowuje reprezentowaną relację preferencji.
- Uogólnienie wydatków i zbioru budżetowego do skończonej liczby dóbr, np. koszyków `Fin n → ℝ`.
- Optimum Ax-x² dla x ≥ 0 i dowolnego A, z rozbiciem na przypadki znaku A.
- Prosta własność zbioru dopuszczalnego lub relacji z Waszego nieopublikowanego modelu.

Pełna równowaga ogólna wymaga większej infrastruktury: przestrzeni, ciągłości, zwartości, własności korespondencji i odpowiednich twierdzeń egzystencjalnych. Wybór małego lematu z takiego dowodu pozwala zacząć pracę badawczą wcześniej niż formalizowanie całego twierdzenia naraz.

AI może proponować kod i wyszukiwać kroki. Akceptacja przez Lean sprawdza dowód zapisanego twierdzenia, ale nie zastępuje kontroli, czy definicje i teza oddają Wasz zamiar naukowy. Nowość naukowa także wymaga osobnej oceny literatury.

## 8. Źródła do dalszej pracy

Materiał i przykłady ekonomiczne przygotowano samodzielnie na potrzeby tego seminarium. Opis działania narzędzi należy porównywać z dokumentacją wersji używanej w projekcie; dokumentacja online może być nowsza od przypiętej biblioteki.

1. Mathematics in Lean, rozdział 2: rachunki, przepisywanie, używanie twierdzeń i struktur: https://leanprover-community.github.io/mathematics_in_lean/C02_Basics.html
2. Mathematics in Lean, rozdział 3: logika i kwantyfikatory: https://leanprover-community.github.io/mathematics_in_lean/C03_Logic.html
3. Dokumentacja taktyk Mathlib: https://leanprover-community.github.io/mathlib4_docs/tactics.html
4. Theorem Proving in Lean 4, Propositions and Proofs: https://docs.lean-lang.org/theorem_proving_in_lean4/Propositions-and-Proofs/
5. Lean Language Reference, Axioms: https://lean-lang.org/doc/reference/latest/Axioms/
6. Dokumentacja `linarith` i `nlinarith`: https://leanprover-community.github.io/mathlib4_docs/Mathlib/Tactic/Linarith/Frontend.html
7. Dokumentacja wypukłości: https://leanprover-community.github.io/mathlib4_docs/Mathlib/Analysis/Convex/Basic.html
8. Dokumentacja monotoniczności: https://leanprover-community.github.io/mathlib4_docs/Mathlib/Order/Monotone/Basic.html
9. Instalacja i projekty Lean: https://leanprover-community.github.io/install/project.html

**Pierwsze zadanie po seminarium:** wybierzcie jeden lemat z Waszego modelu, którego dowód na papierze zajmuje najwyżej kilkanaście wierszy. Przygotujcie jego treść, definicje obiektów, listę założeń i kontrprzykłady uzasadniające kluczowe założenia. To będzie punkt wyjścia drugiego spotkania.
