// Kompilacja: typst compile Prezentacja_Seminarium01.typ
// Samodzielny dokument. Nie wymaga pakietów z Typst Universe ani grafik.
// Materiał opiera się na plikach Seminarium01.lean i Cwiczenia01.lean.

#set document(title: "Lean 4 w ekonomii matematycznej. Seminarium 1", author: "Materiały seminaryjne")
#set page(width: 320mm, height: 180mm,
  margin: (left: 18mm, right: 18mm, top: 20mm, bottom: 17mm),
  fill: white)
#set text(font: "New Computer Modern", size: 21pt, lang: "pl", fill: rgb("#17202D"))
#set par(justify: false, leading: 0.55em, spacing: 0.7em)
#set math.equation(numbering: none)
#show math.equation: set text(font: "New Computer Modern Math")
#show raw: set text(font: ("DejaVu Sans Mono", "New Computer Modern"))
#set list(indent: 18pt, body-indent: 10pt, spacing: 12pt)
#set enum(indent: 18pt, body-indent: 10pt, spacing: 12pt)

#let navy = rgb("#193B6B")
#let pale = rgb("#F0F4FA")
#let gray = rgb("#5A687A")
#let red = rgb("#873D35")

#let note(body) = text(size: 17pt, fill: gray, body)
#let small(body) = text(size: 18pt, body)
#let lean(s, size: 16pt) = block(width: 100%, fill: rgb("#F6F7F9"), inset: 11pt,
  above: 8pt, below: 10pt)[
  #set text(size: size)
  #set par(leading: 0.3em)
  #raw(s, lang: "lean", block: true)
]
#let state(s) = lean(s, size: 17pt)
#let twocol(a, b, ratio: (1fr, 1fr)) = grid(columns: ratio, gutter: 22pt, a, b)
#let statement(title, body, color: navy) = block(width: 100%, above: 9pt, below: 13pt)[
  #block(width: 100%, fill: color, inset: (x: 12pt, y: 7pt))[
    #text(fill: white, size: 20pt, weight: "bold", title)
  ]
  #block(width: 100%, fill: pale, inset: (x: 12pt, y: 11pt))[#body]
]
#let data-table(..cells, columns: (1fr, 2fr), size: 18pt) = {
  set text(size: size)
  table(columns: columns, inset: (x: 10pt, y: 9pt), stroke: (bottom: 0.4pt + rgb("#CAD2DD")),
    fill: (x, y) => if y == 0 { pale } else { none }, ..cells)
}
#let slide(title, section, body) = page(
  header: text(size: 11pt, fill: navy)[Lean 4 w ekonomii matematycznej #h(1fr) #section],
  footer: context [
    #line(length: 100%, stroke: 0.5pt + navy)
    #v(2pt)
    #grid(columns: (1fr, auto),
      text(size: 10pt, fill: gray)[Seminarium 1],
      text(size: 10pt, fill: gray)[#counter(page).display("1") / #counter(page).final().first()])
  ],
)[
  #metadata(title) <slide-title>
  #text(size: 29pt, fill: navy, weight: "bold", title)
  #v(5pt)
  #line(length: 100%, stroke: 0.8pt + navy)
  #v(12pt)
  #body
]

// 1
#slide("Lean 4 w ekonomii matematycznej", "Seminarium 1")[
  #v(20pt)
  #text(size: 31pt)[Podstawy logiki i narzędzia dowodowe]
  #v(18pt)
  #text(size: 24pt, fill: navy)[Od zapisu twierdzenia do sprawdzonego dowodu]
  #v(25pt)
  #line(length: 35%, stroke: 1pt + navy)
  #v(14pt)
  Seminarium dla studenta i promotora

  #note[Praca równolegle z plikiem `Seminarium01.lean` i panelem Lean Infoview]
]

// 2
#slide("Plan pierwszego seminarium", "Organizacja")[
  #data-table(columns: (0.7fr, 2.6fr),
    [*Czas*], [*Zakres*],
    [0–25 min], [Typy, zdania, dowody i odczytywanie Infoview],
    [25–45 min], [Implikacje, kwantyfikatory i koniunkcje],
    [45–70 min], [Równości, nierówności i automatyzacja],
    [70–80 min], [Przerwa],
    [80–120 min], [Użyteczność, preferencje i zbiór budżetowy],
    [120–150 min], [Optymalizacja, ćwiczenia i własny lemat])
  #v(6pt)
  #note[Jedna osoba pisze kod. Druga przewiduje kolejny cel. Role zmieniamy w trakcie pracy.]
]

// 3
#slide("Zakres formalizacji", "Cel")[
  #statement("Matematyka dostępna w bibliotece")[
    Korzystamy z gotowych liczb rzeczywistych, porządku, funkcji i zbiorów w Mathlib.
  ]
  - Definiujemy obiekty modelu i formułujemy założenia.
  - Wyprowadzamy z nich twierdzenia za pomocą istniejącej matematyki.
  - Kontrolujemy zarówno poprawność dowodu, jak i sens zapisanej tezy.
  #v(8pt)
  #note[Przykłady seminaryjne są znanymi wynikami. Ich rolą jest przygotowanie do formalizacji własnego modelu.]
]

// 4
#slide("Zdania jako typy, dowody jako termy", "I. Podstawy")[
  #data-table(columns: (1fr, 2fr),
    [*Lean*], [*Interpretacja*],
    [`x : ℝ`], [$x$ jest liczbą rzeczywistą],
    [`P : Prop`], [$P$ jest zdaniem logicznym],
    [`h : P`], [$h$ jest dowodem zdania $P$],
    [`hPQ : P → Q`], [Dowód $P$ pozwala otrzymać dowód $Q$])
  #v(12pt)
  #statement("Korespondencja Curry’ego–Howarda")[
    Udowodnić $P$ oznacza skonstruować term typu $P$.
  ]
]

// 5
#slide("Typ zdania a jego dowód", "I. Podstawy")[
  #lean("#check (3 : ℕ)\n#check (3 : ℝ)\n#check ((2 : ℝ) + 2 = 5)", size: 19pt)
  #data-table(columns: (1fr, 2fr),
    [*Polecenie*], [*Co ustala system*],
    [`#check`], [Typ wyrażenia, w tym poprawność zapisu zdania],
    [`example ... := by`], [Dowód wskazanej tezy],
    [`sorry`], [Miejsce po brakującym fragmencie dowodu])
  #v(10pt)
  Zdanie fałszywe również ma typ `Prop`.
  Samo `#check` nie rozstrzyga jego prawdziwości.
]

// 6
#slide("Anatomia deklaracji twierdzenia", "I. Podstawy")[
  #lean("example (x y z : ℝ)\n    (hxy : x ≤ y) (hyz : y ≤ z) :\n    x ≤ z := by\n  exact le_trans hxy hyz", size: 19pt)
  #data-table(columns: (1.2fr, 2fr),
    [*Fragment*], [*Rola*],
    [`(x y z : ℝ)`], [Obiekty matematyczne],
    [`(hxy : x ≤ y)`], [Nazwane założenie],
    [`: x ≤ z`], [Teza],
    [`:= by ...`], [Dowód w trybie taktyk])
]

// 7
#slide("Stan dowodu w Infoview", "I. Podstawy")[
  #twocol([
    *Przed taktyką*
    #state("x y z : ℝ\nhxy : x ≤ y\nhyz : y ≤ z\n⊢ x ≤ z")
  ], [
    *Po `apply le_trans hxy`*
    #state("x y z : ℝ\nhxy : x ≤ y\nhyz : y ≤ z\n⊢ y ≤ z")
  ])
  #v(10pt)
  Nad `⊢` znajdują się obiekty i dostępne dowody. Za `⊢` znajduje się bieżąca teza.

  #note[Po każdym kroku ustawiamy kursor za taktyką i porównujemy stan z naszym przewidywaniem.]
]

// 8
#slide("Dostarczenie dowodu i zastosowanie twierdzenia", "II. Logika")[
  #twocol([
    *`exact`: kompletny dowód*
    #lean("example (P : Prop)\n    (hP : P) : P := by\n  exact hP", size: 17pt)
    Dostarczony term ma dokładnie typ bieżącej tezy.
  ], [
    *`apply`: brakujące przesłanki*
    #lean("example (x y z : ℝ)\n    (hxy : x ≤ y)\n    (hyz : y ≤ z) :\n    x ≤ z := by\n  apply le_trans hxy\n  exact hyz", size: 17pt)
  ])
  #v(8pt)
  #note[`le_trans` jest twierdzeniem bibliotecznym. `apply` jest taktyką, która pomaga je zastosować.]
]

// 9
#slide("Implikacja i kwantyfikator ogólny", "II. Logika")[
  #lean("example : ∀ x y : ℝ, x ≤ y → x + 2 ≤ y + 2 := by\n  intro x y hxy\n  exact add_le_add hxy (le_refl 2)", size: 18pt)
  #statement("Znaczenie kroku intro")[
    Wybieramy dowolne $x,y in RR$ i zakładamy $x ≤ y$.
    Następnie dowodzimy $x+2 ≤ y+2$.
  ]
  #state("x y : ℝ\nhxy : x ≤ y\n⊢ x + 2 ≤ y + 2")
]

// 10
#slide("Koniunkcja: budowanie i rozpakowanie", "II. Logika")[
  #twocol([
    *Teza `P ∧ Q`*
    #lean("example (P Q : Prop)\n    (hP : P) (hQ : Q) :\n    P ∧ Q := by\n  constructor\n  · exact hP\n  · exact hQ", size: 17pt)
    `constructor` tworzy dwa cele.
  ], [
    *Hipoteza `h : P ∧ Q`*
    #lean("example (P Q : Prop)\n    (h : P ∧ Q) : P := by\n  obtain ⟨hP, hQ⟩ := h\n  exact hP", size: 17pt)
    `obtain` udostępnia oba składniki.
  ])
  #v(10pt)
  #note[Zapis `rcases h with ⟨hP, hQ⟩` daje tu analogiczne rozpakowanie. Kropka `·` otwiera osobny poddowód.]
]

// 11
#slide("Istnienie: świadek i jego własność", "II. Logika")[
  #twocol([
    *Dowód istnienia*
    #lean("example : ∃ x : ℝ,\n    x > 0 := by\n  use 1\n  norm_num", size: 18pt)
    `use 1` pozostawia do sprawdzenia $1>0$.
  ], [
    *Użycie faktu o istnieniu*
    #lean("example (P : ℝ → Prop)\n    (h : ∃ x, P x) :\n    ∃ y, P y := by\n  obtain ⟨x, hx⟩ := h\n  use x", size: 17pt)
    Otrzymujemy obiekt $x$ i dowód `hx : P x`.
  ])
  #v(10pt)
  #note[W pierwszym przypadku wybieramy świadka tezy. W drugim korzystamy ze świadka dostępnego w założeniu.]
]

// 12
#slide("Ćwiczenia 1 i 3: kontekst i koniunkcja", "II. Ćwiczenia")[
  #statement("Zadanie 1", color: red)[
    #lean("example (P : Prop) (hP : P) : P := by\n  sorry", size: 18pt)
  ]
  #statement("Zadanie 3", color: red)[
    #lean("example (P Q : Prop) (h : P ∧ Q) : Q ∧ P := by\n  sorry", size: 18pt)
  ]
  #note[Przed wpisaniem kodu: co znajduje się w kontekście i jakie cele powinien utworzyć pierwszy krok?]
]

// 13
#slide("Równości: podstawienie za pomocą rw", "III. Rachunki")[
  #lean("example (x y : ℝ) (h : x = y) : x + 1 = y + 1 := by\n  rw [h]", size: 18pt)
  #data-table(columns: (1.1fr, 2fr),
    [*Zapis*], [*Działanie w tym przykładzie*],
    [`rw [h]`], [Podstawienie $y$ za $x$],
    [`rw [← h]`], [Podstawienie $x$ za $y$],
    [`rw [h] at hx`], [Podstawienie we wskazanej hipotezie `hx`])
  #v(10pt)
  #note[Po podstawieniu może pozostać równość identycznych wyrażeń. W takim przypadku `rw` potrafi zakończyć dowód.]
]

// 14
#slide("Definicje i upraszczanie", "III. Rachunki")[
  #lean("def twice (x : ℝ) : ℝ := 2 * x\n\nexample (x : ℝ) : twice x = 2 * x := by\n  rfl\n\nexample (x : ℝ) : twice x + 0 = 2 * x := by\n  simp [twice]", size: 18pt)
  - `rfl` sprawdza równość po redukcji definicji.
  - `simp [twice]` rozwija wskazaną definicję i stosuje reguły upraszczania.
  #note[Przemienność dodawania dla dowolnych parametrów wymaga twierdzenia lub odpowiedniej automatyzacji.]
]

// 15
#slide("Tożsamości wielomianowe", "III. Rachunki")[
  #lean("example (x y : ℝ) (h : x = y + 1) :\n    x ^ 2 = y ^ 2 + 2 * y + 1 := by\n  rw [h]\n  ring", size: 19pt)
  #statement("Dwa odrębne kroki")[
    `rw [h]` wykorzystuje założenie modelu.

    `ring` sprawdza otrzymaną tożsamość wielomianową.
  ]
  #note[Normalizacja wielomianów nie zastępuje świadomego doboru podstawienia.]
]

// 16
#slide("Nierówności liniowe", "III. Rachunki")[
  #lean("example (x y : ℝ)\n    (hx : 2 * x + y ≤ 7) (hy : 1 ≤ y) :\n    x ≤ 3 := by\n  linarith", size: 19pt)
  #statement("Rozumowanie matematyczne")[
    $ 2x+1 ≤ 2x+y ≤ 7 quad ==> quad x ≤ 3. $
  ]
  `linarith` szuka konsekwencji liniowych równości i nierówności w kontekście.

  #note[Przy mnożeniu przez parametr trzeba uwzględnić jego znak, np. przez `mul_le_mul_of_nonneg_left`.]
]

// 17
#slide("Nierówność nieliniowa i lemat pomocniczy", "III. Rachunki")[
  #statement("Teza")[
    $ forall x,y in RR: quad 2 x y ≤ x^2+y^2. $
  ]
  #lean("example (x y : ℝ) : 2 * x * y ≤ x ^ 2 + y ^ 2 := by\n  have hsq : 0 ≤ (x - y) ^ 2 := sq_nonneg (x - y)\n  nlinarith [hsq]", size: 17pt)
  Matematyczny pomysł:
  $ (x-y)^2 = x^2 - 2 x y + y^2 ≥ 0. $
  #note[`have` dodaje udowodniony fakt. `nlinarith` wykonuje rachunek, lecz nie rozwiązuje dowolnej nierówności nieliniowej.]
]

// 18
#slide("Dobór automatyzacji do problemu", "III. Rachunki")[
  #data-table(columns: (0.9fr, 1.6fr, 1.7fr), size: 18pt,
    [*Narzędzie*], [*Typowy cel*], [*Przykład*],
    [`norm_num`], [Konkretny rachunek], [`(4 : ℝ)^3 < 5^3`],
    [`positivity`], [Znak wyrażenia], [`0 ≤ x*y + 1`],
    [`omega`], [Arytmetyka `ℕ`, `ℤ`], [`n < 5` daje `n ≤ 4`],
    [`field_simp`], [Usuwanie mianowników], [`(x+1)/x = 1+1/x`])
  #v(12pt)
  #lean("example (x : ℝ) (hx : x ≠ 0) :\n    (x + 1) / x = 1 + 1 / x := by\n  field_simp [hx]", size: 18pt)
  #note[Warunki o niezerowości mianowników są częścią argumentu matematycznego.]
]

// 19
#slide("Ćwiczenia 6 i 7: wybór uzasadnienia", "III. Ćwiczenia")[
  #statement("Zadanie 6", color: red)[
    #lean("example (x : ℝ) (hx : 3 * x + 2 ≤ 11) : x ≤ 3 := by\n  sorry", size: 17pt)
  ]
  #statement("Zadanie 7", color: red)[
    #lean("example (x : ℝ) : 2 * x ≤ x ^ 2 + 1 := by\n  sorry", size: 18pt)
  ]
  #note[W pierwszym zadaniu wskaż przekształcenia liniowe. W drugim dobierz nieujemny kwadrat. Następnie przerwa.]
]

// 20
#slide("Założenia modelu i aksjomatyka", "IV. Modele ekonomiczne")[
  #lean("example {X : Type*} (R : X → X → Prop)\n    (hTrans : ∀ a b c, R a b → R b c → R a c)\n    (x y z : X) (hxy : R x y) (hyz : R y z) :\n    R x z := by\n  exact hTrans x y z hxy hyz", size: 17pt)
  - `X` opisuje typ alternatyw, a `R` relację na alternatywach.
  - `hTrans` jest jawnym założeniem o tej relacji.
  - Wynik wyprowadza konsekwencję przyjętej własności.
  #note[Globalne `axiom` przyjmuje deklarację bez dowodu. Założenia ekonomiczne zachowujemy jawnie w treści modelu i twierdzeń.]
]

// 21
#slide("Monotoniczność użyteczności afinicznej", "IV. Użyteczność")[
  #statement("Twierdzenie")[
    Niech $u(x)=a x+b$ oraz $a ≥ 0$. Wówczas
    $ x ≤ y quad ==> quad u(x) ≤ u(y). $
  ]
  Dowód na papierze:
  $ x ≤ y quad ==> quad a x ≤ a y quad ==> quad a x+b ≤ a y+b. $
  #v(8pt)
  - Pierwsze przejście wykorzystuje nieujemność $a$.
  - Drugie wykorzystuje zgodność porządku z dodawaniem.
  #note[`Monotone` oznacza niemalejącość. Ścisłą rosnącość zapisujemy jako `StrictMono`.]
]

// 22
#slide("Dowód monotoniczności w Lean", "IV. Użyteczność")[
  #lean("theorem affine_monotone (a b : ℝ) (ha : 0 ≤ a) :\n    Monotone (fun x : ℝ => a * x + b) := by\n  intro x y hxy\n  change a * x + b ≤ a * y + b\n  have hmul : a * x ≤ a * y :=\n    mul_le_mul_of_nonneg_left hxy ha\n  exact add_le_add hmul (le_refl b)", size: 18pt)
  #v(8pt)
  `intro` odsłania definicję monotoniczności. `change` pokazuje wartości funkcji. `have` zapisuje krok mnożenia, a `exact` zamyka dowód.
]

// 23
#slide("Ćwiczenie 8: rosnącość i znak parametru", "IV. Ćwiczenia")[
  #statement("Zadanie 8", color: red)[
    #lean("example (a b : ℝ) (ha : 0 < a) :\n    StrictMono (fun x : ℝ => a * x + b) := by\n  sorry", size: 18pt)
  ]
  - Który krok wymaga założenia $a>0$?
  - Co dzieje się z tezą, gdy $a=0$?
  - Dla $a<0$ podaj konkretne $x≤y$, które obalają niemalejącość.
  #note[Ostatnie pytanie odpowiada idei ćwiczenia 9.]
]

// 24
#slide("Preferencje reprezentowane przez użyteczność", "IV. Preferencje")[
  #statement("Definicja")[
    Dla $u: X arrow RR$ przyjmujemy
    $ x succ.eq y quad <==> quad u(y) ≤ u(x). $
  ]
  #lean("def weakPref {X : Type*} (u : X → ℝ)\n    (x y : X) : Prop := u y ≤ u x", size: 18pt)
  `weakPref u x y` czytamy: $x$ jest co najmniej tak dobry jak $y$.

  #note[Nierówność zapisujemy w kierunku zgodnym z tą konwencją. Dziedzina alternatyw X pozostaje dowolna.]
]

// 25
#slide("Przechodniość preferencji", "IV. Preferencje")[
  $ u(z) ≤ u(y) ≤ u(x) quad ==> quad x succ.eq z. $
  #lean("theorem weakPref_trans {X : Type*} (u : X → ℝ)\n    (x y z : X) (hxy : weakPref u x y)\n    (hyz : weakPref u y z) : weakPref u x z := by\n  change u y ≤ u x at hxy\n  change u z ≤ u y at hyz\n  change u z ≤ u x\n  exact le_trans hyz hxy", size: 17pt)
  #note[Po rozwinięciu definicji korzystamy z przechodniości porządku w ℝ. Kolejność argumentów `hyz`, `hxy` wynika z kierunku nierówności.]
]

// 26
#slide("Zwrotność, zupełność i zakres wyniku", "IV. Preferencje")[
  #data-table(columns: (1fr, 1.6fr, 1.3fr),
    [*Własność*], [*Po rozwinięciu definicji*], [*Uzasadnienie*],
    [Zwrotność], [$u(x) ≤ u(x)$], [`le_refl (u x)`],
    [Zupełność], [$u(y) ≤ u(x) or u(x) ≤ u(y)$], [`le_total (u y) (u x)`])
  #v(14pt)
  #statement("Znaczenie założonej reprezentacji")[
    Użyteczność jest już dana. Twierdzenie o istnieniu reprezentacji dla abstrakcyjnej relacji wymaga osobnego dowodu.
  ]
  #note[Obojętność nie implikuje równości alternatyw. Różne obiekty mogą mieć tę samą użyteczność.]
]

// 27
#slide("Zbiór budżetowy dwóch dóbr", "V. Zbiory budżetowe")[
  $ B(p,w) = {x in RR^2 : x_1 ≥ 0, x_2 ≥ 0, p_1 x_1+p_2 x_2 ≤ w}. $
  #lean("abbrev Bundle := ℝ × ℝ\n\ndef spending (p₁ p₂ : ℝ) (x : Bundle) : ℝ :=\n  p₁ * x.1 + p₂ * x.2\n\ndef budgetSet (p₁ p₂ w : ℝ) : Set Bundle :=\n  {x | 0 ≤ x.1 ∧ 0 ≤ x.2 ∧ spending p₁ p₂ x ≤ w}", size: 17pt)
  #note[`x.1` i `x.2` oznaczają składowe pary. Przynależność do zbioru zawiera trzy warunki.]
]

// 28
#slide("Wzrost dochodu i inkluzja zbiorów", "V. Zbiory budżetowe")[
  #statement("Twierdzenie")[
    $ w_1 ≤ w_2 quad ==> quad B(p,w_1) subset.eq B(p,w_2). $
  ]
  #lean("theorem budget_mono_income (p₁ p₂ w₁ w₂ : ℝ)\n    (hw : w₁ ≤ w₂) :\n    budgetSet p₁ p₂ w₁ ⊆ budgetSet p₁ p₂ w₂ := by\n  intro x hx\n  obtain ⟨hx1, hx2, hxw⟩ := hx\n  exact ⟨hx1, hx2, le_trans hxw hw⟩", size: 17pt)
  #note[Ilości dóbr pozostają nieujemne. Nowy limit wydatków wynika z przechodniości: wydatek ≤ w₁ ≤ w₂.]
]

// 29
#slide("Wypukłość zbioru budżetowego", "V. Zbiory budżetowe")[
  #statement("Definicja wypukłości")[
    Dla $x,y in B$ oraz $a,b ≥ 0$ takich, że $a+b=1$,
    $ a x+b y in B. $
  ]
  Nieujemność składowych kombinacji wynika z nieujemności wag i składowych koszyków.

  Dla wydatków:
  $ p dot (a x+b y) = a (p dot x)+b (p dot y)
      ≤ a w+b w = (a+b)w = w. $
  #note[W Lean korzystamy ze standardowej definicji `Convex ℝ`, zgodnej z tą kombinacją wypukłą.]
]

// 30
#slide("Wypukłość w Lean: struktura celu", "V. Zbiory budżetowe")[
  #lean("theorem budget_convex (p₁ p₂ w : ℝ) :\n    Convex ℝ (budgetSet p₁ p₂ w) := by\n  intro x hx y hy a b ha hb hab\n  obtain ⟨hx1, hx2, hxw⟩ := hx\n  obtain ⟨hy1, hy2, hyw⟩ := hy", size: 18pt)
  #data-table(columns: (1fr, 2fr),
    [*Informacja*], [*Znaczenie*],
    [`ha`, `hb`], [$a≥0$, $b≥0$],
    [`hab`], [$a+b=1$],
    [`hxw`, `hyw`], [Wydatki koszyków $x$ i $y$ nie przekraczają $w$])
  #note[Po odsłonięciu definicji `constructor` rozdzieli nieujemność składowych i ograniczenie wydatków.]
]

// 31
#slide("Wypukłość w Lean: rachunek wydatków", "V. Zbiory budżetowe")[
  #lean("calc\n  p₁ * (a * x.1 + b * y.1) + p₂ * (a * x.2 + b * y.2)\n      = a * spending p₁ p₂ x + b * spending p₁ p₂ y := by\n        dsimp [spending]\n        ring\n  _ ≤ a * w + b * w :=\n    add_le_add (mul_le_mul_of_nonneg_left hxw ha)\n      (mul_le_mul_of_nonneg_left hyw hb)\n  _ = (a + b) * w := by ring\n  _ = w := by rw [hab, one_mul]", size: 16pt)
  #note[`calc` zapisuje łańcuch uzasadnionych przejść. Podkreślenie `_` powtarza prawą stronę poprzedniego kroku. Pełny dowód jest w pliku seminaryjnym.]
]

// 32
#slide("Niepustość a wypukłość", "V. Ćwiczenia")[
  #statement("Ćwiczenie 11", color: red)[
    Załóż $w≥0$. Udowodnij istnienie dopuszczalnego koszyka.
    #lean("example (p₁ p₂ w : ℝ) (hw : 0 ≤ w) :\n    ∃ x : ℝ × ℝ, 0 ≤ x.1 ∧ 0 ≤ x.2 ∧\n      p₁ * x.1 + p₂ * x.2 ≤ w := by\n  sorry", size: 17pt)
  ]
  #small[
    *Wskazówka:* wybierz koszyk zerowy.

    Wypukłość zachodzi tu dla dowolnych rzeczywistych cen i dochodu. Niepustość oraz ograniczoność wymagają osobnego uzasadnienia.
  ]
]

// 33
#slide("Globalne maksimum funkcji kwadratowej", "VI. Optymalizacja")[
  #statement("Twierdzenie")[
    Dla $u_A(x)=A x-x^2$, gdzie $A,x in RR$,
    $ u_A(x) ≤ u_A(A/2). $
  ]
  *Certyfikat optymalności:*
  $ u_A(A/2)-u_A(x) = (x-A/2)^2 ≥ 0. $
  #v(8pt)
  To oszacowanie globalne. Nie wymaga obliczania pochodnej ani założenia o znaku $A$.
]

// 34
#slide("Dowód optymalności w Lean", "VI. Optymalizacja")[
  #lean("def quadraticUtility (A x : ℝ) : ℝ := A * x - x ^ 2\n\ntheorem quadratic_global_max (A x : ℝ) :\n    quadraticUtility A x ≤ quadraticUtility A (A / 2) := by\n  dsimp [quadraticUtility]\n  have hsq : 0 ≤ (x - A / 2) ^ 2 := sq_nonneg (x - A / 2)\n  nlinarith [hsq]", size: 17pt)
  #v(8pt)
  - `dsimp` odsłania definicję funkcji celu.
  - `have` zapisuje matematyczny pomysł dowodu.
  - `nlinarith` weryfikuje rachunek wielomianowy.
]

// 35
#slide("Dopuszczalność i optimum przy x ≥ 0", "VI. Optymalizacja")[
  #lean("theorem quadratic_nonneg_optimum (A : ℝ) (hA : 0 ≤ A) :\n    ∃ x : ℝ, 0 ≤ x ∧ ∀ y : ℝ, 0 ≤ y →\n      quadraticUtility A y ≤ quadraticUtility A x := by\n  use A / 2\n  constructor\n  · positivity\n  · intro y _hy\n    exact quadratic_global_max A y", size: 17pt)
  #statement("Rola założenia A ≥ 0")[
    Zapewnia dopuszczalność kandydata $A/2$. Optymalność wynika z wcześniejszego oszacowania na całym $RR$.
  ]
]

// 36
#slide("Ćwiczenie 10: maksimum i jego uzasadnienie", "VI. Ćwiczenia")[
  #statement("Zadanie 10", color: red)[
    #lean("example (x : ℝ) : 6 * x - x ^ 2 ≤ 9 := by\n  sorry", size: 20pt)
  ]
  + Wskaż punkt osiągania wartości $9$.
  + Zapisz różnicę między $9$ a wartością funkcji jako kwadrat.
  + Zastosuj `sq_nonneg` i odpowiednią taktykę arytmetyczną.
  #v(8pt)
  #note[Dalszy projekt: maksimum Ax − x² na x ≥ 0 dla dowolnego A. Wymaga rozpatrzenia znaku parametru.]
]

// 37
#slide("Kontrola treści formalnego wyniku", "VII. Praca badawcza")[
  - Czy dziedziny i kierunki relacji odpowiadają modelowi?
  - Gdzie wykorzystujemy dodatniość, niezerowość i dopuszczalność?
  - Czy założenia nie czynią tezy niezamierzenie trywialną?
  - Czy ukończone wyniki zawierają brakujące dowody?
  #lean("#print axioms quadratic_nonneg_optimum", size: 19pt)
  #note[W tym przykładzie otrzymujemy standardowe zależności `propext`, `Classical.choice`, `Quot.sound`. Obecność `sorryAx` wskazywałaby na lukę.]
]

// 38
#slide("Pierwszy lemat z własnego modelu", "VII. Praca badawcza")[
  #statement("Materiał na następne seminarium")[
    Twierdzenie z Waszego modelu, którego dowód na papierze zajmuje kilkanaście wierszy, wraz z definicjami i pełną listą założeń.
  ]
  + Dobór definicji odpowiadających interfejsom Mathlib.
  + Podział dowodu na małe lematy.
  + Wyszukanie twierdzeń i kontrola ich typów przez `#check`.
  + Formalny dowód oraz ponowna kontrola jego interpretacji.
  #note[Możliwy temat: zachowanie preferencji przez ściśle rosnącą transformację użyteczności.]
]

// 39
#slide("Materiały do dalszej pracy", "VII. Źródła")[
  #set text(size: 20pt)
  - #link("https://leanprover-community.github.io/mathematics_in_lean/C02_Basics.html")[*Mathematics in Lean*, rozdział 2] \
    Rachunki, twierdzenia biblioteczne i struktury algebraiczne.
  - #link("https://leanprover-community.github.io/mathematics_in_lean/C03_Logic.html")[*Mathematics in Lean*, rozdział 3] \
    Logika, kwantyfikatory i rozpakowywanie założeń.
  - #link("https://leanprover-community.github.io/mathlib4_docs/tactics.html")[*Dokumentacja taktyk Mathlib*] \
    Dokładne działanie oraz ograniczenia poszczególnych narzędzi.
  - #link("https://docs.lean-lang.org/theorem_proving_in_lean4/Propositions-and-Proofs/")[*Theorem Proving in Lean 4*] \
    Zdania, dowody i podstawy reprezentacji formalnej.
  #v(6pt)
  #note[Pliki robocze: `Seminarium01.lean`, `Cwiczenia01.lean`, `Rozwiazania01.lean`. Dodatek zawiera ściągę i wybrane rozwiązania.]
]

// 40
#slide("Dodatek: logika i stan dowodu", "Dodatek A. Ściąga")[
  #data-table(columns: (1.2fr, 1.5fr, 1.7fr), size: 18pt,
    [*Postać celu*], [*Typowy pierwszy krok*], [*Znaczenie*],
    [`P → Q`], [`intro hP`], [Załóż P, dowiedź Q],
    [`∀ x, P x`], [`intro x`], [Wybierz dowolny x],
    [`P ∧ Q`], [`constructor`], [Dowiedź obu składników],
    [`P ↔ Q`], [`constructor`], [Dowiedź obu kierunków],
    [`∃ x, P x`], [`use x`], [Wskaż świadka],
    [`P ∨ Q`], [`left` lub `right`], [Wybierz składnik],
    [Dostępny dowód P], [`exact hP`], [Zamknij cel P])
  #v(8pt)
  #note[W hipotezie: `obtain ⟨...⟩ := h` rozpakowuje koniunkcję lub istnienie. Negacja ¬P oznacza P → False.]
]

// 41
#slide("Dodatek: rachunki i narzędzia", "Dodatek A. Ściąga")[
  #data-table(columns: (1.2fr, 2.1fr), size: 18pt,
    [*Narzędzie*], [*Zastosowanie*],
    [`rw [h]`, `rw [← h]`], [Podstawianie zgodnie z równością],
    [`simp [definicja, h]`], [Upraszczanie z podanymi informacjami],
    [`ring`], [Tożsamości wielomianowe],
    [`linarith`], [Liniowe konsekwencje równości i nierówności],
    [`nlinarith [h]`], [Wybrane rachunki nieliniowe, z dodatkowymi faktami],
    [`positivity`, `norm_num`], [Znaki wyrażeń i konkretne obliczenia],
    [`omega`], [Liniowa arytmetyka liczb naturalnych i całkowitych],
    [`field_simp [hx]`], [Usuwanie mianowników przy warunkach o niezerowości])
]

// 42
#slide("Rozwiązania ćwiczeń 1 i 3", "Dodatek B. Rozwiązania")[
  #twocol([
    *Ćwiczenie 1*
    #lean("example (P : Prop)\n    (hP : P) : P := by\n  exact hP", size: 17pt)
    Dowód tezy jest już dostępny w kontekście.
  ], [
    *Ćwiczenie 3*
    #lean("example (P Q : Prop)\n    (h : P ∧ Q) : Q ∧ P := by\n  obtain ⟨hP, hQ⟩ := h\n  constructor\n  · exact hQ\n  · exact hP", size: 16pt)
    Rozpakowujemy dane i konstruujemy nową koniunkcję.
  ])
]

// 43
#slide("Rozwiązania ćwiczeń 6 i 7", "Dodatek B. Rozwiązania")[
  *Ćwiczenie 6: nierówność liniowa*
  #lean("example (x : ℝ) (hx : 3 * x + 2 ≤ 11) : x ≤ 3 := by\n  linarith", size: 18pt)
  #v(7pt)
  *Ćwiczenie 7: nieujemność kwadratu*
  #lean("example (x : ℝ) : 2 * x ≤ x ^ 2 + 1 := by\n  have hsq : 0 ≤ (x - 1) ^ 2 := sq_nonneg (x - 1)\n  nlinarith [hsq]", size: 18pt)
  #note[Uzasadnienie drugiego zadania: x² − 2x + 1 = (x−1)² ≥ 0.]
]

// 44
#slide("Rozwiązania ćwiczeń 8 i 10", "Dodatek B. Rozwiązania")[
  *Ćwiczenie 8: ścisła rosnącość*
  #lean("example (a b : ℝ) (ha : 0 < a) :\n    StrictMono (fun x : ℝ => a * x + b) := by\n  intro x y hxy\n  change a * x + b < a * y + b\n  have hmul : a * x < a * y := mul_lt_mul_of_pos_left hxy ha\n  exact add_lt_add_of_lt_of_le hmul (le_refl b)", size: 16pt)
  *Ćwiczenie 10: optimum kwadratowe*
  #lean("example (x : ℝ) : 6 * x - x ^ 2 ≤ 9 := by\n  nlinarith [sq_nonneg (x - 3)]", size: 17pt)
]

// 45
#slide("Rozwiązanie ćwiczenia 11 i kontrprzykład", "Dodatek B. Rozwiązania")[
  *Ćwiczenie 11: koszyk zerowy*
  #lean("example (p₁ p₂ w : ℝ) (hw : 0 ≤ w) :\n    ∃ x : ℝ × ℝ, 0 ≤ x.1 ∧ 0 ≤ x.2 ∧\n      p₁ * x.1 + p₂ * x.2 ≤ w := by\n  use (0, 0)\n  simpa using hw", size: 17pt)
  *Ćwiczenie 9: ujemny współczynnik kierunkowy*
  #lean("example : ∃ x y : ℝ, x ≤ y ∧ (-1) * x > (-1) * y := by\n  use 0, 1\n  norm_num", size: 17pt)
]

// 46
#slide("Indukcja i hipoteza indukcyjna", "Dodatek C. Indukcja")[
  #lean("def doubleNat : ℕ → ℕ\n  | 0 => 0\n  | n + 1 => doubleNat n + 2\n\ntheorem doubleNat_eq (n : ℕ) : doubleNat n = 2 * n := by\n  induction n with\n  | zero =>\n    rfl\n  | succ n ih =>\n    rw [doubleNat, ih]\n    ring", size: 17pt)
  #note[W kroku indukcyjnym `ih` jest już dostępnym dowodem dla n. Używamy go do przypadku n+1.]
]

// 47
#slide("Uruchomienie i organizacja pracy", "Dodatek D. Projekt")[
  Polecenia wykonujemy w katalogu zawierającym `lakefile.lean`.
  #lean("cd ~/Desktop/LEAN_SEMINARIUM/seminarium_1/Seminarium01_Lean4\nlake update\nlake exe cache get\nlake env lean Seminarium01.lean\nlake env lean Rozwiazania01.lean", size: 18pt)
  #small[
    - Wersje opisują `lean-toolchain` oraz `lakefile.lean`.
    - Ćwiczenia zawierają celowe miejsca `sorry`. Gotowe dowody powinny być kompletne.
    - Pracę modelową prowadzimy w repozytorium z zachowanym `lake-manifest.json`.
  ]
  #note[Polecenia powyżej wpisujemy w terminalu, a nie w pliku .lean.]
]
